
const API = "/proxy/5000/api";;

function getToken() {
    return localStorage.getItem("token");
}

function escapeHTML(value) {
    const div = document.createElement("div");
    div.textContent = value ?? "";
    return div.innerHTML;
}

// API Request
async function apiRequest(url, options = {}) {
    const headers = {
        "Content-Type": "application/json",
        ...(getToken() ? {
            Authorization: "Bearer " + getToken()
        } : {}),
        ...(options.headers || {})
    };

    const response = await fetch(API + url, {
        ...options,
        headers
    });

    const text = await response.text();

    let data;
    try {
        data = JSON.parse(text);
    } catch {
        throw new Error("Server error: " + text);
    }

    if (!response.ok) {
        throw new Error(data.message || "Request failed");
    }

    return data;
}

// Logout
function logout() {
    localStorage.removeItem("token");
    window.location.href = "login.html";
}

// LOGIN
const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", async function(e) {
        e.preventDefault();

        const message = document.getElementById("message");

        try {
            const data = await apiRequest("/login", {
                method: "POST",
                body: JSON.stringify({
                    username: document.getElementById("username").value,
                    password: document.getElementById("password").value
                })
            });

            localStorage.setItem("token", data.token);
            window.location.href = "index.html";

        } catch (error) {
            message.textContent = error.message;
        }
    });
}

// REGISTER
const registerForm = document.getElementById("registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", async function(e) {
        e.preventDefault();

        const message = document.getElementById("message");

        try {
            const data = await apiRequest("/register", {
                method: "POST",
                body: JSON.stringify({
                    name: document.getElementById("name").value,
                    username: document.getElementById("username").value,
                    password: document.getElementById("password").value
                })
            });

            localStorage.setItem("token", data.token);
            window.location.href = "index.html";

        } catch (error) {
            message.textContent = error.message;
        }
    });
}

// CHECK LOGIN
async function checkLogin() {
    if (!getToken()) {
        window.location.href = "login.html";
        return false;
    }

    try {
        await apiRequest("/me");
        return true;
    } catch (error) {
        logout();
        return false;
    }
}

// CREATE POST
async function createPost() {
    const content = document.getElementById("postContent").value;

    if (!content.trim()) {
        alert("Please write something!");
        return;
    }

    try {
        await apiRequest("/posts", {
            method: "POST",
            body: JSON.stringify({ content })
        });

        document.getElementById("postContent").value = "";
        loadPosts();

    } catch (error) {
        alert(error.message);
    }
}

// DISPLAY POSTS
function displayPosts(posts, containerId) {
    const container = document.getElementById(containerId);

    if (!container) return;

    if (!posts || !posts.length) {
        container.innerHTML = "<p>No posts available.</p>";
        return;
    }

    container.innerHTML = posts.map(post => `
        <div class="post">
            <h3>${escapeHTML(post.name)}</h3>
            <small>@${escapeHTML(post.username)}</small>
            <p>${escapeHTML(post.content)}</p>

            <div class="post-actions">
                <button onclick="likePost('${post.id}')">
                    ❤️ Like
                </button>
                <span>${post.likes?.length || 0} Likes</span>
            </div>

            <div class="comments">
                ${(post.comments || []).map(c => `
                    <p><b>@${escapeHTML(c.username)}:</b>
                    ${escapeHTML(c.comment)}</p>
                `).join("")}
            </div>

            <form class="comment-form" data-post-id="${post.id}">
                <input type="text" name="comment"
                    placeholder="Write a comment..." required>
                <button type="submit">Send</button>
            </form>
        </div>
    `).join("");

    container.querySelectorAll(".comment-form").forEach(form => {
        form.addEventListener("submit", async function(e) {
            e.preventDefault();

            try {
                await apiRequest(
                    "/posts/" + form.dataset.postId + "/comments",
                    {
                        method: "POST",
                        body: JSON.stringify({
                            comment: form.elements.comment.value
                        })
                    }
                );

                if (containerId === "profilePosts") {
                    loadProfile();
                } else {
                    loadPosts();
                }

            } catch (error) {
                alert(error.message);
            }
        });
    });
}

// LOAD POSTS
async function loadPosts() {
    try {
        const posts = await apiRequest("/posts");
        displayPosts(posts, "postsContainer");
    } catch (error) {
        console.error(error);
    }
}

// LIKE POST
async function likePost(id) {
    try {
        await apiRequest("/posts/" + id + "/like", {
            method: "POST"
        });

        if (document.getElementById("profilePosts")) {
            loadProfile();
        } else {
            loadPosts();
        }

    } catch (error) {
        alert(error.message);
    }
}

// LOAD PROFILE
async function loadProfile() {
    try {
        const user = await apiRequest("/me");

        document.getElementById("profileDetails").innerHTML = `
            <h3>${escapeHTML(user.name)}</h3>
            <p>@${escapeHTML(user.username)}</p>
        `;

        const profile = await apiRequest(
            "/profile/" + encodeURIComponent(user.username)
        );

        displayPosts(profile.posts, "profilePosts");

    } catch (error) {
        alert(error.message);
    }
}

// START WEBSITE
if (document.getElementById("postsContainer")) {
    checkLogin().then(valid => {
        if (valid) loadPosts();
    });
}

if (document.getElementById("profileDetails")) {
    checkLogin().then(valid => {
        if (valid) loadProfile();
    });
}
