
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
require("dotenv").config();

const { readDB, writeDB } = require("./database");

const app = express();
const PORT = process.env.PORT || 5000;
const SECRET = process.env.JWT_SECRET || "socialconnect_secret";

app.use(cors());
app.use(express.json());

// Serve frontend files from Frontend folder
app.use(express.static(path.join(__dirname, "..")));

function authenticate(req, res, next) {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
        return res.status(401).json({ message: "Please login first" });
    }

    try {
        req.user = jwt.verify(token, SECRET);
        next();
    } catch {
        res.status(401).json({ message: "Invalid or expired token" });
    }
}

// Register
app.post("/api/register", async (req, res) => {
    try {
        const { name, username, password } = req.body;

        if (!name || !username || !password) {
            return res.status(400).json({ message: "All fields are required" });
        }

        if (password.length < 6) {
            return res.status(400).json({
                message: "Password must have at least 6 characters"
            });
        }

        const db = readDB();

        if (db.users.some(u => u.username.toLowerCase() === username.trim().toLowerCase())) {
            return res.status(400).json({ message: "Username already exists" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = {
            id: Date.now().toString(),
            name: name.trim(),
            username: username.trim(),
            password: hashedPassword
        };

        db.users.push(user);
        writeDB(db);

        const token = jwt.sign(
            { id: user.id, username: user.username },
            SECRET,
            { expiresIn: "1d" }
        );

        res.status(201).json({
            message: "Registration successful",
            token
        });
    } catch (error) {
        res.status(500).json({ message: "Registration failed" });
    }
});

// Login
app.post("/api/login", async (req, res) => {
    const { username, password } = req.body;
    const db = readDB();

    const user = db.users.find(
        u => u.username.toLowerCase() === String(username || "").trim().toLowerCase()
    );

    if (!user || !(await bcrypt.compare(password || "", user.password))) {
        return res.status(400).json({ message: "Invalid username or password" });
    }

    const token = jwt.sign(
        { id: user.id, username: user.username },
        SECRET,
        { expiresIn: "1d" }
    );

    res.json({ message: "Login successful", token });
});

// Current user
app.get("/api/me", authenticate, (req, res) => {
    const db = readDB();
    const user = db.users.find(u => u.id === req.user.id);

    if (!user) return res.status(404).json({ message: "User not found" });

    res.json({
        id: user.id,
        name: user.name,
        username: user.username
    });
});

// Get all posts
app.get("/api/posts", (req, res) => {
    const db = readDB();
    res.json(db.posts.slice().reverse());
});

// Create post
app.post("/api/posts", authenticate, (req, res) => {
    const { content } = req.body;

    if (!content || !content.trim()) {
        return res.status(400).json({ message: "Post cannot be empty" });
    }

    const db = readDB();
    const user = db.users.find(u => u.id === req.user.id);

    if (!user) return res.status(404).json({ message: "User not found" });

    const post = {
        id: Date.now().toString(),
        userId: user.id,
        name: user.name,
        username: user.username,
        content: content.trim(),
        likes: [],
        comments: [],
        date: new Date().toISOString()
    };

    db.posts.push(post);
    writeDB(db);

    res.status(201).json(post);
});

// Like or unlike post
app.post("/api/posts/:id/like", authenticate, (req, res) => {
    const db = readDB();
    const post = db.posts.find(p => p.id === req.params.id);

    if (!post) return res.status(404).json({ message: "Post not found" });

    const index = post.likes.indexOf(req.user.id);

    if (index === -1) {
        post.likes.push(req.user.id);
    } else {
        post.likes.splice(index, 1);
    }

    writeDB(db);
    res.json(post);
});

// Add comment
app.post("/api/posts/:id/comments", authenticate, (req, res) => {
    const { comment } = req.body;
    const db = readDB();
    const post = db.posts.find(p => p.id === req.params.id);

    if (!post) return res.status(404).json({ message: "Post not found" });

    if (!comment || !comment.trim()) {
        return res.status(400).json({ message: "Enter a comment" });
    }

    const user = db.users.find(u => u.id === req.user.id);

    post.comments.push({
        username: user.username,
        comment: comment.trim()
    });

    writeDB(db);
    res.json(post);
});

// Get user profile and posts
app.get("/api/profile/:username", (req, res) => {
    const db = readDB();
    const user = db.users.find(
        u => u.username.toLowerCase() === req.params.username.toLowerCase()
    );

    if (!user) return res.status(404).json({ message: "User not found" });

    const posts = db.posts.filter(p => p.userId === user.id).reverse();

    res.json({
        name: user.name,
        username: user.username,
        posts
    });
});

app.listen(PORT, () => {
    console.log(`SocialConnect server running on port ${PORT}`);
    console.log(`Open http://localhost:${PORT}`);
});
