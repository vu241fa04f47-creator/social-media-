
const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "db.json");

function readDB() {
    if (!fs.existsSync(dbPath)) {
        fs.writeFileSync(
            dbPath,
            JSON.stringify({ users: [], posts: [] }, null, 2)
        );
    }

    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
}

function writeDB(data) {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

module.exports = { readDB, writeDB };
